import model.Customer;
import service.CustomerServices;

import java.util.Collection;

public class Tester {
    public static void main(String[] args) {
        MainMenu initial=new MainMenu();
        initial.run();
    }
}
